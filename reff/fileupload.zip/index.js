var express = require("express");
var multer = require("multer");
var app = express();
var uploaded = false;
var upload_dir = "./uploads";


app.use(multer({
    dest : upload_dir,
    rename : function(fieldname, filename){
        return filename
    },
    onFileUploadStart : function(file){
        console.log(file.originalName+" is now uploaded")
    },
    onFileUploadComplete : function(file){
        console.log(file.fieldname+" is uploaded to "+file.path);
        uploaded = true;
    }
    }))

app.get("/", function(req,res){
    res.render("img_upload.ejs");
})
app.post("/", function(req, res){
    if(uploaded){
        console.log(req.files);
        res.end("File is now uploaded");
    }
})

app.listen(5566, function(){
    console.log("server running on 5566")
})



